#pragma once 

#include <iostream>
#include <conio.h>
#include "Keymap.h"

using std::cout, std::endl;

class KeyboardInputHandler {
public:
    static int next();
};